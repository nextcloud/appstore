<?php

$tmpl = new \OCP\Template('twofactor_u2f', 'personal');

return $tmpl->fetchPage();
