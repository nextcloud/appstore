news (9.0.4)
* **Bugfix**: Pad API last modified timestamp to milliseconds in updated items API to return only new items. API users however need to re-sync their complete contents, #24
* **Bugfix**: Do not pad milliseconds for non millisecond timestamps in API

news (9.0.3)
* **Security (Low)**: Prevent browsers like Chrome from auto-filling your Nextcloud login credentials into Basic Auth form. This could lead users to accidentally saving their credentials in the database and disclosing them to the feed source when the feed is added/updated

news (9.0.2)
* **Bugfix**: Do not return millisecond lastModified timestamps in API, #20

news (9.0.1)
* **Enhancement**: Drop PHP 64bit requirement due to helpful suggestions

news (9.0.0)
* **New dependency**: Bump minimum Nextcloud version to 10
* **New dependency**: PHP 64bit required
* **Backwards incompatible change**: Updating to 9.0.0 is only possible from 8.8.0 or higher due complex database schema changes.
* **Enhancement**: Further cleanups for the Nextcloud app store
* **Bugfix**: Fix cronjob updates on Nextcloud 10
* **Bugfix**: Limit iframes to 100% width, #10

news (8.8.3)
* **Enhancement**: Cleanups for the Nextcloud app store

news (8.8.0)
* **Enhancement**: Remove current pull to refresh implementation since it is more annoying than helpful.
* **Enhancement**: Add API route for supported API levels

news (8.7.5)
* **Security (High)**: Fix security bug that would allow websites to access your DOM document when using keyboard shortcuts to open an article in a new tab, downloading audio files, opening links on the explore page or opening links to the ownCloud documentation or issue tracker (News app versions prior to 5.0.0 are also vulnerable when clicking on any link in the title or article body). This gives any attacker access to all data on the DOM and allows them to make arbitrary requests to the ownCloud server on the user's behalf, bypassing CSRF protection and gaining full access to their account by stealing their login cookies. For a more detailed explanation [visit this website](https://medium.com/@jitbit/target-blank-the-most-underestimated-vulnerability-ever-96e328301f4c#.h55ny7ef0)

news (8.7.4)
* **Bugfix**: Fix expand in compact view mode, #988

news (8.7.3)
* **Bugfix**: Rerun fingerprint and search index generation in case it was not run properly before
* **Bugfix**: Do not swallow errors when generating search indices and fingerprints

news (8.7.2)
* **Security**: Sign application to make missing/outdated files more easily detectable and prevent attackers from potentially serving a malicious News app from the app store

news (8.7.1)
* **Bugfix**: Send Chrome's user agent string instead of our own since mod_security, which is used on some servers, thinks that only browsers are allowed to send user agents. This will fix feed updates for some websites, e.g. joomla.org, (because we all know that Joomla is big on security ;) ), #978

news (8.7.0)
* **Enhancement**: Better lock down Composer versions to prevent shipping newer PHP libraries then intended when compiling the project
* **Enhancement**: Mark current article as active while scrolling
* **Enhancement**: Clicking on an article sets it as active, #791
* **Enhancement**: Keyboard shortcuts will target the currently active element, #791

news (8.6.0)
* **Enhancement**: Also publish error count and last error message through API, #977

news (8.5.0)
* **Bugfix**: Do not run feed updates when ajax or web cron mode was detected because it can lead to very long load times, timeouts, data corruption, update bugs where feeds are not updated anymore and database inconsistencies. If someone is interested in re-enabling webcron based feed updates, please create a PHP script which uses the [updater API](https://github.com/owncloud/news/wiki/Updater-1.2). Don't hesitate to ask for help on the issue tracker!
* **Bugfix**: Fix multiple error messages and outdated links for cron error messages

news (8.4.1)
* **Bugfix**: Fix error messages in the logs which were caused by outdated template includes, #972

news (8.4.0)
* **Enhancement**: Use the feed url when showing an example of a curl command if a feed does not exist, #969
* **Enhancement**: Also filter duplicate items from web frontend when in folder, starred or all articles view, #465

news (8.3.0)
* **Bugfix**: If two folders with the same name occur in a OPML file, merge them instead of simply ignoring the second one, #962
* **Enhancement**: Better error messages for SSL issues, #966
* **Enhancement**: Rename oc_news_feeds columns etag and last_modified to http_etag and http_last_modified

news (8.2.1)
* **Bugfix**: Do not abort full OPML import if one feed failed, #843
* **Bugfix**: Show error message when empty OPML file was imported, #924

news (8.2.0)
* **Backwards incompatible change**: Move updater into separate repository at https://github.com/owncloud/news-updater and publish it on pypi
* **Bugfix**: Make the export/import buttons smaller so they fit in a line on ownCloud 9.0
* **Enhancement**: Marking an item as read will now mark all similar items of the same user as read, regardless of the feed, #465
* **Enhancement**: Add a link to the documentation and bugtracker in the settings area

news (8.1.0)
* **Backwards incompatible change**: URLs for the Python updater must now start with either http:// or https://
* **Enhancement**: Change Python updater License from AGPL3+ to GPL3+
* **Bugfix**: Fix bug that would not package all JavaScript files for the app store zip, #959
* **Enhancement**: Add console API to update feeds in parallel
* **Enhancement**: Add an additional parameter to specify the loglevel for the Python updater
* **Enhancement**: Adjust Python updater to be able to use the console API. If you pass an absolute directory as url (path to your ownCloud), the updater will try to use **occ** updater commands using php. This requires no user or password arguments which makes running the updater on the same system as your ownCloud more secure

news (8.0.0)
* **Backwards incompatible change**: The git repository does not bundle composer and bower libraries anymore, nor does it contain compiled JavaScript. If you are running the git version, you now need to run **make** after cloning and pulling from the repository to install the depenencies and compile the JavaScript
* **New dependency**: Bump minimum ownCloud version to 9.0
* **New dependency**: Bump minimum PostgreSQL version to 9.4
* **New dependency**: Bump minimum MySql/MariaDB version to 5.5
* **New dependency**: Bump minimum PHP version to 5.6
* **Bugfix**: Fix bug that would not lowercase non ASCII characters when searching, #944
* **Bugfix**: Fix bug that would not persist settings like compact mode on PostgreSQL, #948
* **Enhancement**: Add support for password protected feeds (HTTP basic auth), #938

news (7.1.2)
* **Enhancement**: Major JavaScript library updates:
  * Update from Angular 1.3 to 1.5
  * Use Gulp instead of Grunt
  * CSS is not minified anymore to make CSS contributions easier
* **Enhancement**: Update picoFeed
* **Bugfix**: Fix bug that would sometimes break the rendering of the explore page

news (7.1.1)
* **Enhancement**: Add vk.com to allowed iframe sources
* **Enhancement**: Add blog.fefe.de to German explore feeds
* **Enhancement**: Add Trump's video channel to English explore feeds

news (7.1.0)
* **Backwards incompatible change**: Change explore URL API to request a file instead of URL parameter
* **Enhancement**: Improve explore feeds page design
* **Enhancement**: Add more feeds on the explore feeds page
* **Enhancement**: Add a list of German feeds for the explore page
* **Enhancement**: Allow to select other languages than the currently set language

news (7.0.1)
* **Enhancement**: Show text preview in compact mode
* **Bugfix**: Fix bug that broke the app when using Italian translations , #913

news (7.0.0)
* **New dependency**: Bump required ownCloud version to 8.2
* **Backwards incompatible change**: Remove console commands and instead run them after specific updates
* **Bugfix**: Fix bug that prevented non admin users from changing feed parameters, #903
* **Enhancement**: If a feed failed to update more than 100 times, show a hint in the web interface
* **Enhancement**: Overwrite active feed styling to make it look like in ownCloud 8.1, #897

news (6.1.1)
* **Security**: Update picoFeed to add an [XXE fix for php-fpm](http://framework.zend.com/security/advisory/ZF2015-06) on systems with PHP <5.5.22 or >5.6 and <5.6.6. This issue allows any user with access to the News app to read abitrary files from the server. For more information read up on the [Zend advisory](http://framework.zend.com/security/advisory/ZF2015-06) and the [OWASP page](https://www.owasp.org/index.php/XML_External_Entity_%28XXE%29_Processing). Affected supported distributions include [Ubuntu 14.04](https://bugs.launchpad.net/ubuntu/trusty/+source/php5/+bug/1509817)

news (6.1.0)
* **Backwards incompatible change**: Removed several web routes and feed service methods by generalizing feed object changes using a patch method
* **Enhancement**: Update articles if the pubdate is newer than the current one, #877
* **Enhancement**: Add feed setting to mark updated articles as unread, #882
* **Enhancement**: Made app compatible with ownCloud 9

news (6.0.6)
* **Enhancement**: Align settings text properly, #829
* **Enhancement**: Update picoFeed to include additional feed rules

news (6.0.5)
* **Bugfix**: Fix icon width for article action plugins
* **Bugfix**: Submit search on Firefox when hitting enter, #863
* **Enhancement**: Add user information API route

news (6.0.4)
* **Bugfix**: Allow YouTube videos to go fullscreen, #857
* **Enhancement**: Group plugins in menu, #718

news (6.0.3)
* **Enhancement**: Allow to pin feeds, #848

news (6.0.2)
* **Bugfix**: Generate search index when importing articles
* **Enhancement**: Be less precise when jumping to the next article using a keyboard shortcut to prevent tiny jumps which are sometimes caused by re-rendering hiccups, #847
* **Enhancement**: Add RTL support

news (6.0.1)
* **Enhancement**: Replace unlicensed PHP library with a licensed alternative

news (6.0.0)
* **New dependency**: Require PHP 5.5
* **Support**: Drop CentOS support
* **Bugfix**: Fix bug that would not delete a user's table entries after deletion
* **Enhancement**: Add **news:verify-install** command to help diagnosing missing or out of date files
* **Enhancement**: Rather than always enhancing feeds based on rules, use picoFeeds full text feed capability
* **Enhancement**: Enable enhancers per feed rather than globally for rules available
* **Enhancement**: Add News app releases to example feeds in explore section

news (5.3.9)
* **Bugfix**: Also warn when webcron is enabled since it is possible that the update will time out or only work sporadically, #828

news (5.3.8)
* **Bugfix**: Make the searchbox reappear in 8.1

news (5.3.7)
* Skipped because of wrong git tag

news (5.3.6)
* **Bugfix**: Firefox: Mark article as read if middle click on the title is performed
* **Bugfix**: Firefox: Scroll to top before refresh to prevent accidentally marking articles as read

news (5.3.5)
* **Bugfix**: Downgrade Angular from 1.4 to 1.3 due to several regressions
* **Bugfix**: Fix video playback for certain videos

news (5.3.4)
* **Bugfix**: Do not reorder feeds and folders when their names are edited, #790
* **Bugfix**: Update links in cron warning notice

news (5.3.3)
* **Enhancement**: Add shortcut for marking the current article's feed/folder read, #635
* **Bugfix**: When collapsing an article in compact view, remove content to stop playing audio/video from iframes, #787
* **Bugfix**: If expand in compact view is enabled, keyboard shortcuts will now expand the first item if the scroll position is at the top and the first item has not been expanded yet, #786

news (5.3.2)
* **Enhancement**: Disable expand on key navigation setting if compact view is not enabled, #774
* **Bugfix**: Update picoFeed to the latest version to fix a bug that would cause the fetcher timeout setting to be ignored
* **Bugfix**: Make settings checkboxes clickable by themselves
* **Bugfix**: Hide menu (which only contains the mark read button) for all articles feed if all articles are read, #775
* **Bugfix**: Fix issue that would make it impossible to refresh by jumping to previous article once jump to next shortcut was used after the refresh drop down became visible, #770

news (5.3.1)
* **Enhancement**: Make entire area for adding feeds and folders clickable
* **Enhancement**: Do not use as much space for longer headings in compact mode
* **Bugfix**: Also use the set curl timeout in addition to the connect timeout to react to timeouts after connections which is important for slow feeds, #763

news (5.3.0)
* **Enhancement**: Make it possible to search articles in the search field. To migrate older articles to this functionality, check the README section "Updating from versions prior to 5.3.0", #185
* **Enhancement**: Stop video and audio playback if a new video or audio file is being played
* **Enhancement**: Do not stop playing podcasts when the feed is being reloaded or changed, #156
* **New dependency**: Bump required ownCloud version to 8.1

news (5.2.8)
* **Bugfix**: Fix feed subscribe to URL
* **Enhancement**: Provide checksums for all files

news (5.2.7)
* **Enhancement**: If the app is called with the subscribe\_to url parameter (e.g. **?subscribe_to=http://path.to/feed**) the feed input is prefilled with the address
* **Enhancement**: Register the app as feed reader in Firefox

news (5.2.6)
* **Bugfix**: Update picoFeed to strip out contents of script and style tags which were previously converted into plain text, #723

news (5.2.5)
* **Bugfix**: Fix flying loading icon since snap.js does not seem to want to fix it
* **Bugfix**: Turn all http iframes into https iframes
* **Bugfix**: Set a CSP to display external media on master

news (5.2.4)
* **Enhancement**: Add a new API route to check for the status and possible problems

news (5.2.3)
* **Enhancement**: Push explore button at the bottom of the feed list
* **Enhancement**: When passing a negative batchSizes to the item API, all items will be returned

news (5.2.2)
* **Security**: Only allow YouTube and Vimeo to embed iframes if they use HTTPS to prevent mixed active content iframe attacks

news (5.2.1)
* **Bugfix**: Fix admin settings by using the correct config path

news (5.2.0)
* **New dependency**: Require iconv php module (which is required by picoFeed)

news (5.1.1)
* **Bugfix**: Use the correct scrolltop position for pull to refresh to not reload the feed when jumping back to an article using keyboard shortcuts

news (5.1.0)
* **Backwards incompatible change**: Break client side plugin API to combat limitations that make it hard to impossible to get the DOM element
* **New dependency**: Bump required ownCloud version to 8 beta 2
* **Enhancement**: Expose feed ordering parameter in API

news (5.0.1)
* **Enhancement**: Show error messages when authentication or network related errors appear
* **Enhancement**: Show a pull to refresh area if you are at the very top and jump to the previous article using either page up or a jump to previous article shortcut. If this area is already visible reload the page
* **Enhancement**: Make it possible to overwrite the global ordering for certain feeds

news (5.0.0)
* **New dependency**: Bump required ownCloud version to 8
* **Enhancement**: Set the rel="noreferrer" attribute for all links that point to external articles to enhance privacy

news (4.3.2)
* **Bugfix**: Update picoFeed to fix an HTTP cache problem where only one match (Etag or Last-Modified) was required to mark a feed as not modified. This can cause some feeds to not update if one cache parameter is always the same
* **Enhancement**: If a feed is added without the protocol, prepend https:// instead of http:// (e.g. adding cnn.com would result in https://cnn.com being added)

news (4.3.1)
* **Bugfix**: Update picoFeed to fix feed format detection, e.g. http://aroundthebloc.podbean.com/feed/ was previously not recognized as a valid feed
* **Enhancement**: Add thecodinglove.com and der-postilion.com enhancers
* **Enhancement**: Make it possible to define your own article actions by adding article action plugins

news (4.3.0)
* **Backwards incompatible change**: Refactor the Python updater into a Python package. To stay with the old behavior without installing the package use **python3 -m bin/updater/owncloud_news_updater YOUROPTIONS**
* **Backwards incompatible change**: Use seconds instead of minutes for the Python updater interval
* **New dependency**: Require requests 2.5.0 for the Python updater
* **Enhancement**: Ship a systemd and sysvinit script + installer for the Python updater to run the updater in the background
* **Enhancement**: Log errors from Python updater to stderr
* **Enhancement**: Add metronieuws.nl article enhancer

news (4.2.6)
* **Bugfix**: Wording fixes
* **Enhancement**: Add linuxtoday.com article enhancer
* **Enhancement**: Make expand entries in compact view after jumping to next/previous feed optional with a setting

news (4.2.5)
* **Bugfix**: Fix keep unread shortcut in compact view

news (4.2.4)
* **Bugfix**: Clicking the button to open a website in compact view now marks the article read
* **Bugfix**: Make read on scroll more sensitive in compact view to mark it read without having to completely scroll over the entry
* **Enhancement**: Better explanation for reverse ordering setting
* **Enhancement**: Do not expand entries in compact view when using the jump to next/previous article shortcuts since this makes it harder to keep an overview and the exact same behavior is available in expanded view anyways

news (4.2.3)
* **Bugfix**: Fix cron update

news (4.2.2)
* **Enhancement**: Use a light gradient at the bottom of the feed when no items are left to autopage

news (4.2.1)
* **Bugfix**: Rewrite relative URLs

news (4.2.0)
* **Security**: Fix [XEE](https://www.owasp.org/index.php/XML_External_Entity_(XXE)_Processing) vulnerability in picoFeed RSS library. All versions starting from 4.0.0 are affected
* **Enhancement**: Add admin setting to set a custom explore service URL
* **Enhancement**: Add explore button and show explore button on startup
* **Enhancement**: Show a hint when no articles are available
* **Enhancement**: Add spiegel.de enhancer
* **Bugfix**: Fix compact view in firefox 34 and browsers using the new flexbox model
* **Bugfix**: Show spinner when autopaging
* **Bugfix**: Remove race condition when fetching articles that sometimes shows read articles if the user clicks show on only unread and the article request finishes first before the settings request is finished
* **Bugfix**: Ignore Atom updated tag if it is earlier than the published tag
* **Bugfix**: Do not log errors that a subscription could not be found when http cache says nothing changed

news (4.1.3)
* **Enhancement**: Fade out folders and feeds instead of just hiding them when the unread count drops to 0 and only unread articles should be shown

news (4.1.2)
* **Enhancement**: Order feeds and folder sorting by title and name rather than by id

news (4.1.1)
* **Enhancement**: shortcut **a** scrolls to the currently active feed in the navigation
* **Enhancement**: next/previous feed/folder shortcuts now scroll to the active entry if it is not fully in view

news (4.1.0)
* **Backwards incompatible change**: Time used for updating when using the Python updater is now subtracted from the given interval meaning: if you specify 30 seconds as interval and the update takes 25 seconds, it will sleep for 5 seconds before running the next update
* **Enhancement**: Show a message if ajax cron is used to inform people of improperly configured cron
* **Enhancement**: Allow to specify configuration file for Python updater
* **Enhancement**: Add short command line options for the Python updater
 * -u, --user
 * -p, --password
 * -i, --interval
 * -s, --timeout

news (4.0.4)
* **Bugfix**: Do not indent slashdot.org italic elements
* **Bugfix**: Hide folders when only showing unread articles after marking all articles as read

news (4.0.3)
* **Bugfix**: Fix unstarring and starring articles added before 4.x

news (4.0.2)
* **Bugfix**: Fix CORS headers for getting the version via the API
* **Enhancement**: Transform YouTube urls to allow subscribing to channels and playlists

news (4.0.1)
* **Bugfix**: Fix heise.de encoding issues

news (4.0.0)
* **Backwards incompatible change**: Calculate item ids differently which leads to unpreventable readding of read articles
* **Backwards incompatible change**: Get rid of simplePieCacheDuration setting, remove this setting from your data/news/config/config.ini after upgrading to 4.\*.*
* **Backwards incompatible change**: Use three numbers for versioning because core bug with versions seems fixed
* **Enhancement**: Add maxRedirects setting in config.ini
* **Enhancement**: Add maxSize setting in config.ini
* **Enhancement**: Get rid SimplePie feed parser library and switch to PicoFeed because SimplePie is unmaintained and full of bugs
* **Enhancement**: Faster feed updates due to proper HTTP cache headers thanks to picoFeed
* **Enhancement**: Use ownCloud internal proxy settings
* **Enhancement**: Allow to turn off article purging by setting a negative number
* **Enhancement**: Make article cleanup faster
* **Bugfix**: Set the correct header for the FirefoxOS manifest.webapp
* **Bugfix**: Fix article cleanup on sqlite

news (3.406)
* **Enhancement**: Make config.ini editable in the admin interface

news (3.405)
* **Bugfix**: Fix mobile view for ownCloud 7
* **Enhancement**: Add shortcuts for jumping to next/previous folder
* **Enhancement**: Add keyboard shortcuts overview
* **Enhancement**: More space for checkboxes in settings overview

news (3.404)
* **Bugfix**: Fix freeze when a folder is selected, the previous folder has 0 visible subfeeds and the **d** shortcut is pressed to jump the the previous feed

news (3.403)
* **Bugfix**: Use correct route for python updater

news (3.402)
* **New dependency**: Bump required ownCloud version to 7.0.3 (RC1 is also supported)
* **Bugfix**: Use **News** as the app navigation entry name across all languages to fix translation errors and because it makes sense

news (3.401)
* **New dependency**: SimpleXML
* **Enhancement**: Added Slashdot.org enhancer to get rid of tons of advertising that create a lot of whitespace when using adblock
* **Enhancement**: When a folder or feed of a folder is selected, select that folder in the add new feed section

news (3.302)
* **Bugfix**: Fix text overflow for subscriptions and starred feed
* **Bugfix**: Styles for h4, h5 and h6
* **Bugfix**: Support 7.0.3 alpha release
* **Enhancement**: Minify CSS
* **Enhancement**: Minify JavaScript

news (3.301)
* **New dependency**: ownCloud >= 7.0.3
* **Security**: Fix possible [XEE](https://www.owasp.org/index.php/XML_External_Entity_(XXE)_Processing) due to race conditions on php systems using **php-fpm**
* **Bugfix**: Fix issue that prevented going below 1 unread count in the window title
* **Enhancement**: Show a button to refresh the page instead of reloading the route for pull to refresh

news (3.202)
* **Security**: Fix [XEE](https://www.owasp.org/index.php/XML_External_Entity_(XXE)_Processing) on systems with libxml < 2.9 which allows attackers to add a malicious feeds that can include any file content that is readable by the webserver
* **Enhancement**: Provide manifest to make News an installable web app on Firefox OS
* **Enhancement**: Switch keep unread and star icon

news (3.201)
* **New dependency**: Minimum libxml version: 2.7.8
* **Bugfix**: Move open website icon in compact view to the left of the title
* **Bugfix**: SimplePie: Do not break if url encoded links contain non ASCII chars
* **Bugfix**: Favicon should stay in place if you expand an article in compact view
* **Bugfix**: Go back to debug level logging for feed updates
* **Bugfix**: Fix heise.de feeds

news (3.105)
* **Bugfix**: Various wording fixes
* **Bugfix**: Do not use Import/Export caption for settings buttons to avoid UI bugs in translated versions
* **Bugfix**: Catch all exceptions for feed update to not also not fail completely after db errors
* **Bugfix**: Register error handler only once
* **Bugfix**: Fix German translation
* **Bugfix**: Load app config also when in cron mode
* **Bugfix**: Log feed create and update errors to owncloud log as error because debug is broken

news (3.104)
* **Bugfix**: Backport ownCloud CSS z-index fix to ownCloud 7 for settings popup that made it difficult to access the administration tab

news (3.103)
* **Bugfix**: Turn all errors into exceptions to prevent failing all feed updates if one update runs into an error

news (3.102)
* **Bugfix**: Fix z-index for stable7 so menu buttons dont overlap content in mobile view
* **Bugfix**: Use public namespace for template script and style template functions

news (3.101)
* **Bugfix**: Fix remove YouTube autoplay on libxml versions < 2.6
* **Enhancement**: Backport to ownCloud 7

news (3.003)
* **Bugfix**: Correctly toggle title of star and keep unread icons
* **Bugfix**: Fix bug that prevented the webinterface's update every 60 seconds
* **Enhancement**: Less padding right on mobile phone
* **Enhancement**: Expanded view: remove date on mobile phone
* **Enhancement**: Compact view: click on title should remove ellipsis
* **Enhancement**: Ignore autoPurgeMinimumInterval setting if it is below 60 seconds since anything lower than that may hurt user experience
* **Enhancement**: Remove YouTube autoplay from all articles

news (3.002)
* **Bugfix**: If a folder is selected, the f and d shortcuts will jump to the previous or next folder subfeeds
* **Bugfix**: Fix o shortcut in expanded view
* **Bugfix**: Make **em** tag cursive and black
* **Enhancement**: Cut mark read timeout in half
* **Enhancement**: Show full unread count when hovering over the unread count

news (3.001)
* **New dependency**: Minimum ownCloud version: 8
* **New dependency**: Minimum PHP version: 5.4
* **Breaking Change**: Plugin API: BusinessLayer has been renamed to Service, (FeedBusinessLayer -> FeedService) and different exceptions are now thrown to make failure better distinguishable, accessing the BusinessLayer links to the Service equivalents to keep compability
* **Bugfix**: Disable drag and drop if a feed is in an invalid state
* **Bugfix**: Focus scrollable area if the page is loaded initially
* **Bugfix**: Immediate feedback if folder/feed exists already on the client side
* **Bugfix**: Reload current folder if a feed is moved into or out of it
* **Bugfix**: Pixel perfect folder and feed inputs
* **Bugfix**: Do not include starred count of deleted folders and feeds
* **Bugfix**: Display error messages when folder rename failed
* **Bugfix**: Enter works now as submitting a form for every input
* **Bugfix**: Import feeds from a very large OPML file in chunks to prevent server slowdown
* **Bugfix**: Folder names are not uppercased anymore due to possible naming conflicts caused by folders being created through the API
* **Bugfix**: Loading icon is now displayed until all feeds and folders are loaded
* **Enhancement**: Correctly float heise.de info box
* **Enhancement**: Allow to turn off marking read when scrolling
* **Enhancement**: Allow to order by oldest first
* **Enhancement**: Add clientside routing
* **Enhancement**: When importing OPML use the feed title if given
* **Enhancement**: Make hover buttons available under a menu button
* **Enhancement**: Slim down appstore build
* **Enhancement**: Allow to specifiy custom CSS rules for each feed
* **Enhancement**: Compact view: Title ellipsis
* **Enhancement**: Compact view: Show source as favicon
* **Enhancement**: Compact view: Add keep unread button
* **Enhancement**: Compact view: Expand item when jumping to it with a keyboard shortcut
* **Enhancement**: Move undo feed/folder deletion button into the navigation bar
* **Enhancement**: Add create folder form in addition to the subscribe form
* **Enhancement**: Optimize for mobile
* **Enhancement**: Move show unread articles setting into the settings area
* **Enhancement**: New add feed design
* **Enhancement**: API: add parameter to get items by oldest first
* **Enhancement**: Keyboard Shortcut: r to reload the current feed
* **Enhancement**: Keyboard Shortcut: f to load the next feed/folder
* **Enhancement**: Keyboard Shortcut: d to load the previous feed/folder
* **Enhancement**: Set useragent for fetching feeds
* **Enhancement**: Also support video enclosures
* **Enhancement**: Port clientside code from CoffeeScript to JavaScript
* **Enhancement**: Respect theme name in tab title

news (2.003)
* Use correct url for folder and feed api update methods

news (2.002)
* Better check for news app dependencies
* Security: Don't send CORS Allow-Credentials header to prevent CSRF

news (2.001)
* Delete folders, feeds and articles if a user is deleted
* Also remember collapsed folders on postgres
* Fix bug that would prevent articles from being deleted if a folder is marked as deleted on sqlite and postgres
* Require ownCloud 6.0.3
* Remove html tags from feed titles
* Port to built in core App Framework and thus removing the need to install the App Framework
* Fix bug that would break news if a feed contains audio enclosures
* Prepare news to work with proxies once [Simple Pie is patched](https://github.com/simplepie/simplepie/pull/360)
* Update HTMLPurifier to incorporate security fixes from the [newest release](http://htmlpurifier.org/news/2013/1130-4.6.0-released)
* **New dependency**: python-requests library for the python updater script

news (1.808)
* Also focus article area when clicking on all unread link
* Autofocus article area by default on load
* Instantiate only one itemcontroller, prevents tons of requests when autopaging
* Fix bug that would disable keyboard shortcuts after the star icon has been clicked

news (1.807)
* Don't crash if an HttpException occurs in the python updater
* Add API call to rename a feed
* Don't collapse articles in compact mode if you select a new article to prevent the scroll position from changing

news (1.806)
* Disable simple pie sanitation (we use HtmlPurifier) to speed up update
* Only purify articles if they will be added to the database
* Fix XSS vulnerability that was caused by not purifing the body of imported articles
* Also float the first picture in the first div left (fixes ugly images for golem.de feed)

news (1.805)
* Hide editing tools in invalid feed dialog
* Use local copies of icons to reflect changes in oc 7

news (1.804)
* Make it possible to rename folders
* Do not show rename action for feeds that could not be added
* Trim URL in invalid feed modal
* Article enhancer for
  - niebezpiecznik.pl

news (1.803)
* Use the feed link if an item doesn't specificy a link
* Don't fail if article url does not exist but fall back to feed url
* Article enhancers for
  - nerfnow.com
  - sandraandwo.com
  - geek-and-poke.com
  - nichtlustig.de
  - thegamercat.com
  - twokinds.keenspot.com

news (1.802)
* Increase performance by not making auto page requests anymore if the last result didn't contain any articles

news (1.801)
* Add ability to rename feeds
* Compact view
* Add shortcut to expand items in compact view

news (1.605)
* Adding feeds does not block the input box any more
* Always display empty folders
* Better description for hiding/showing read articles
* Make it easier to add simple article enhancers by moving the data into a JSON configuration file
* Add regex based item enhancers
* Article enhancers for
  - buttersafe.com
  - twogag.com
  - cad-comic.com
  - penny-arcade.com
  - leasticoulddo.com
  - escapistmagazine.com
  - trenchescomic.com
  - lfgcomic.com
  - sandraandwoo.com
  - theoatmeal.com
  - loldwell.com
  - mokepon.smackjeeves.com

news (1.604)
* Use 64bit integers to prevent running out of ids after a year for large installations
* Fix postgres feed queries with correct group by
* Article enhancers now transform relative links on a page to absolute links

news (1.603)
* Fix JavaScript errors which prevented the translation elements from being removed

news (1.602)
* Remove removed class from container
* Go back to allow feeds per url from input
* Added ThemeRepublic.net Enhancer
* Remove unsigned from articles_per_update column to not fail with a weird error
* Manually convert &apos; to ' in title and author fields of articles because its not build into PHP
* Fix localisation of app name in tab title

news (1.601)
* Remove Google Reader import
* Replace Google Reader import with export and import of unread and starred articles
* Autopurge limit is now added to the number of articles each feed gets when it updates
* Fix CORS headers for OPTIONS request deeper than one level
* Use before and after update cleanup hooks to make sure that read items are not turned unread again after an update. This breaks custom updaters. The updater script has been adjusted accordingly
* Implement pull to refresh
* Use Bower for JavaScript dependency management

news (1.404)
* Fix bug on postgres databases that would not delete old articles

news (1.403)
* Respect encoding in feed enhancers
* Hotfix for update on posgresql databases

news (1.402)
* Add possibility of adding more than one xpath for article enhancer
* Fix bug that wouldn't delete old read articles

news (1.401)
* Add possibility to hook up article enhancers which fetch article content directly from the web page
* Add article enhancer for explosm.net to directly fetch comics and shorts
* Possible backwards incompatible change by using the link provided by simplepie instead of the user for the url hash. This prevents duplication of the feed when adding a slightly different feed url which points to the same feed and allows a speedup from O(n) to O(1) for article enhanchers
* Add an option route for the API which handles the CORS headers to allow webapplications to access the API
* Also allow youtube and vimeo embeds that start with // and https:// instead of only allowing http
* ownCloud 6 compability fixes
* Throw proper error codes when creating invalid folders through the API
* More whitespace to fit ownCloud 6 design better
* Increased unread count from 99+ to maximum of 999+ because there is now more space
* Use a configuration file in data/news/config/config.ini to not overwrite uservalues on update
* Fix bug in python updater api that would trigger a method not allowed error
* Add first run page that shows all options expanded if there are no feeds and the app is launched for the first time

news (1.206)
* Also handle URLErrors in updater script that are thrown when the domain of a feed is not found

news (1.205)
* Also allow magnet urls in articles
* When jumping to the next item after the last one, also mark the last item as read

news (1.204)
* Fix problem that caused python updater script to exit because of maximum recursion
* Add an option to testrun an update with the updater script

news (1.203)
* Decode the title twice to fix special characters in HTML content in the title, author and email
* Scroll to the bottom once you hit the show all button to prevent tedious scrolling
* Add an API to make ownCloud cron updates optionally. This can be used to write an update script which can be threaded to dramatically speed up fetching of feeds and reduce the used memory to run the update
* Add a Python update script which threads the updates
* Make it possible to turn off cron updates
* Strip all HTML tags from the author and title
* Sanitize urls on the server side to prevent clients from being affected by XSS
* Use a default batch value for the API
* Don't fail to import OPML which uses the title instead of text attribute (i.e. OPML created by Thunderbird)

news (1.202)
* Fixed a bug in the API routes that would request an uneeded id when creating a feed
* Log unimportant errors on debug level instead of error level

news (1.201)
* Add shortcut 'o' which opens the current article in a new tab
* Speed up updating of feeds by more than 100% by not fetching favicons and unneeded https/http variants
* Moved to new RESTful API to fix API bugs
* Fix bug that wouldnt mark items as read if they were set read in a folder, feed or all read request
* Style blockquotes
* Fixed small CSS bug that would remove the bottom margin of every last element
* Increased allowed feed timeout from 10 to 60 seconds
* Make it possible for plugins to turn off mark read on scroll
* Removed HTML Purifier unit tests which made it possible to trigger XSS using a crafted URL
* Don't update existing articles anymore if the pubdate changes to prevent weird update behaviour
* If articles dont provide a pubdate, use the date when the article was saved in the database
* Display download link if audio file is not playable

news (1.001)
* Also use monospace for pre tag
* Fix bug that would prevent feed updates when feeds or folders are deleted

news (0.104)
* Also html decode the links to the page to not break on nyaa torrents

news (0.103)
* Fixed a bug that prevented deleting feeds when a folder was deleted

news (0.102)
* Fix marking read of all articles and folders on mysql and postgres
* Fix bug that would still show items after its feed or folder has been marked as deleted
* Fix bug that would show invalid unread count for feeds whose folders were deleted

news (0.101)

* show 99+ as max unread count
* only show delete button if feed is active
* Fix a bug that would show the loading sign when updating the web ui and would reload all items while reading
* More accurate padding when hovering over a feed
* Require 5.0.6 which includes a fix for the core API
* Don't highlight the tab title when there are no new unread feeds
* Make only one http request for reading all items and all items of a folder
* Fix bug that would prevent marking a feed as read when its created and no other feeds are there
* Fix bug that would prevent readding of a feed when a folder containing the feed was deleted
* Also send newest item id in the api when creating a feed
* Fix a bug that would mark the items on the right side as read regardless of feed or folder id
* Fix a bug that would a feed from being added when he was deleted and then another feed was deleted
* When a feed is deleted and not undone in 10 seconds and the window is closed, delete him
* Fix bug that would make links containing hashes unclickable
* Fix bug that broke the News app on postgresql
* Fix bug that prevented the API from serving items

news (0.98)

* Fix XSS vulnerability in sanitation for json import
* Fix XSS vulnerability in feed and title link

news (0.97)

* Fix XSS vulnerability in sanitation
* Properly show embedded vimeo and youtube videos

news (0.96)

* Always open links in new tabs
* Better exception handling for controllers
* Implemented API
* Fixed a bug that would prevent update of the News app
* Log feed update errors
* Make add website button less obstrusive
* Fixed problem with sites that updated too frequently like youtube
* Also update folders

news (0.95)

* Fix a bug that would cause PHP 5.3 to fail while parsing utf-8
* Reverted the keep unread checkbox styling from a button back to a normal checkbox
* Fix an issue that prevented scrolling when drag and dropping a feed in to a new folder
* Do not mark items as read that have not yet been displayed to the user
* Autopage if there are 10 items left instead of 4 times the scroll area height, fixes a bug that would not load new items if the entry was too big
* Prefer website favicon over channel image, fixes wordpress blog favicons
* Add all businesslayer methods for the current API spec
* API Specification Draft
* Fix a bug that would cause words in the headlines to always be wrapped
* Fix a bug that would cause the ellipsis on the "Add Website" entry to be too short
* Provide undo dialog for feed and folder deletion
* Do not preload audio in podcast feed
* Use utf-8 charset header in JSON responses to prevent broken headlines
* Move the rss cache files into the ownCloud data directory
* Autopurge: limit read articles per feed instead of using a global limit
* Use tooltips for delete and mark read button
* Also load the newest unread and starred count when a feed is loaded
* Do not request updates from the client but only use the background job to make the app faster
* Add a way to import articles from Google Reader Takeout Archive
* Fix a bug in favicon fetcher that would not fetch certain favicons
* Add OPML export
* Show translated relative dates for articles
* Show immediate feedback when adding a feed or folder
* Add keyboard shortcuts
* Do not show unread articles feed when there are no feeds
* Filter HTML tags from headlines and authors
* If the article author has no name use the mail
* Show full feed name on hover
* If feed has no name, use its URL
* Do not update articles all the time that have no pubdate
* Prevent app from making ownCloud unusable if the App Framework is not installed
* Focus the articles area when a feed is being clicked so page up/page down work
* Use a delay for drag and drop to make experience on Mac OS X better
* Show unread count in the tab title
